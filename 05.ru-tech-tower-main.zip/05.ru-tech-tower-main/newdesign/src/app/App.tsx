import DivMxAuto from "../imports/DivMxAuto";

export default function App() {
  return (
    <div className="min-h-screen bg-[#0f1b20] overflow-auto">
      <DivMxAuto />
    </div>
  );
}
